﻿
namespace WinFormsApp4
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.TextBox();
            this.lblbtn1 = new System.Windows.Forms.Button();
            this.appName = new System.Windows.Forms.Button();
            this.lblbtn3 = new System.Windows.Forms.Button();
            this.lblSignUp = new System.Windows.Forms.LinkLabel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(318, 125);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(201, 23);
            this.txtName.TabIndex = 0;
            this.txtName.Text = "Name";
            // 
            // lblPassword
            // 
            this.lblPassword.Location = new System.Drawing.Point(318, 181);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.PasswordChar = '*';
            this.lblPassword.Size = new System.Drawing.Size(201, 23);
            this.lblPassword.TabIndex = 1;
            // 
            // lblbtn1
            // 
            this.lblbtn1.Location = new System.Drawing.Point(207, 125);
            this.lblbtn1.Name = "lblbtn1";
            this.lblbtn1.Size = new System.Drawing.Size(75, 23);
            this.lblbtn1.TabIndex = 2;
            this.lblbtn1.Text = "Name";
            this.lblbtn1.UseVisualStyleBackColor = true;
            // 
            // appName
            // 
            this.appName.Location = new System.Drawing.Point(207, 181);
            this.appName.Name = "appName";
            this.appName.Size = new System.Drawing.Size(75, 23);
            this.appName.TabIndex = 3;
            this.appName.Text = "Password";
            this.appName.UseVisualStyleBackColor = true;
            // 
            // lblbtn3
            // 
            this.lblbtn3.Location = new System.Drawing.Point(207, 254);
            this.lblbtn3.Name = "lblbtn3";
            this.lblbtn3.Size = new System.Drawing.Size(75, 23);
            this.lblbtn3.TabIndex = 4;
            this.lblbtn3.Text = "Submit";
            this.lblbtn3.UseVisualStyleBackColor = true;
            this.lblbtn3.Click += new System.EventHandler(this.lblbtn_Click);
            // 
            // lblSignUp
            // 
            this.lblSignUp.AutoSize = true;
            this.lblSignUp.Location = new System.Drawing.Point(362, 254);
            this.lblSignUp.Name = "lblSignUp";
            this.lblSignUp.Size = new System.Drawing.Size(45, 15);
            this.lblSignUp.TabIndex = 5;
            this.lblSignUp.TabStop = true;
            this.lblSignUp.Text = "SignUp";
            this.lblSignUp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblSignUp_LinkClicked);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Cooper Black", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.textBox1.Location = new System.Drawing.Point(250, 33);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(251, 40);
            this.textBox1.TabIndex = 6;
            this.textBox1.Text = "JOB HUNTER";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(826, 450);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblSignUp);
            this.Controls.Add(this.lblbtn3);
            this.Controls.Add(this.appName);
            this.Controls.Add(this.lblbtn1);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.txtName);
            this.Name = "LoginForm";
            this.Text = "Login Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

       
        private System.Windows.Forms.TextBox lblPassword;
        private System.Windows.Forms.Button lblbtn3;
        private System.Windows.Forms.Button lblbtn2;
        private System.Windows.Forms.Button lblbtn1;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.LinkLabel lblSignUp;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button appName;
    }
}

