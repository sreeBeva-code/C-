﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculator
{
    public partial class Form1 : Form
    {
        Double result = 0;
        String oparetionfrom = "";
        bool isopperfrom = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BTNCLIC(object sender, EventArgs e)
        {
            if ((textBoxresult.Text == "0")||(isopperfrom))
                textBoxresult.Clear();
            isopperfrom = false;

            Button button=(Button)sender;
            if(button.Text==".")
            {
                if (!textBoxresult.Text.Contains("."))
                    textBoxresult.Text = textBoxresult.Text + button.Text;
            }else
            textBoxresult.Text = textBoxresult.Text + button.Text;
        }

        private void OPRATECLIC(object sender, EventArgs e)
        {
            Button button = (Button)sender;
           
                oparetionfrom = button.Text;
                result = Double.Parse(textBoxresult.Text);
                labelfi.Text = result + " " + oparetionfrom;
                isopperfrom = true;
                    

        }

        private void button17_Click(object sender, EventArgs e)
        {
            textBoxresult.Text = "0";
        }

        private void button15_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            textBoxresult.Text = "0";
            result = 0;

        }

        private void textBoxresult_TextChanged(object sender, EventArgs e)
        {

        }

        private void button15(object sender, EventArgs e)
        {
            switch (oparetionfrom)
            {
                case "+":
                    textBoxresult.Text = (result + Double.Parse(textBoxresult.Text)).ToString();
                    break;
                case "-":
                    textBoxresult.Text = (result - Double.Parse(textBoxresult.Text)).ToString();
                    break;
                case "*":
                    textBoxresult.Text = (result * Double.Parse(textBoxresult.Text)).ToString();
                    break;
                case "/":
                    textBoxresult.Text = (result / Double.Parse(textBoxresult.Text)).ToString();
                    break;
                default:
                    break;
            }
            result = Double.Parse(textBoxresult.Text);
            labelfi.Text = "";
        }
    }
}
